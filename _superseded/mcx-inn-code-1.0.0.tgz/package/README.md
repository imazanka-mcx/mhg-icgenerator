# @mcx/inn-code

The MHG Inn Code Standard (MHG-IC v1.0) as a library: derives five-character
property codes from the rule ladder and issues them atomically against a
registry of record.

```
EVVHX
└┬┘└┬┘
 │  └── flag   — chars 4-5, from the closed brand table (B1)
 └───── market — chars 1-3, from the M ladder
```

**The one thing to understand:** the formula proposes, the registry disposes.
`deriveCode` is a suggestion. `issueCode` is the only call that makes a code
real, because only it takes the atomic claim. Any code path that generates a
code without claiming it will eventually produce a duplicate (G8).

---

## Install

The package lives in the OpsCore monorepo. From the repo root:

```bash
npm install          # installs typescript + vitest
npm test             # 57 tests
npm run build        # emits dist/
```

## Quick start

```ts
import { MHG_CONFIG, MemoryRegistry, issueCode } from '@mcx/inn-code';

const deps = { config: MHG_CONFIG, registry: new MemoryRegistry() };

const result = await issueCode(deps, {
  name: 'Hampton Inn Evansville East',
  city: 'Evansville',
  state: 'IN',
  brandCode: 'HX',
  submarket: 'East',
  franchisorCode: 'EVVIN',
});

if (result.ok) {
  result.record.code;        // 'EVVHX'
  result.record.propertyId;  // internal key — this is your foreign key, not the code
  result.trace;              // [{ rule: 'M2', detail: 'EVV — primary commercial airport…' }, …]
} else {
  result.failure.rule;       // 'M5'
  result.failure.message;    // 'Name the submarket. M5 splits on a real place…'
}
```

Every result carries a `trace` of the rules that fired, in order. Show it in
the UI — it is why someone can look at `SNTMB` and see that Santa Claus was
refused `SAN` because that is San Diego.

## API

| Function | What it does |
|---|---|
| `deriveCode(deps, req)` | Proposes a code. Reads the registry, writes nothing. Safe on every keystroke. |
| `issueCode(deps, req, attempts?)` | Derives, then atomically claims. Retries on a lost race by re-deriving. |
| `rebrand(deps, oldCode, newFlag, overrides?)` | G2. Issues the new code, keeps the internal id, retires the old code. |
| `validateCode(config, code)` | G4 + G7 + B1 field-level check. No registry, no I/O. |
| `baseMarket(config, city, state)` | M1–M4 only. Pure. "What would this market's code be?" |
| `resolveMarket(config, registry, req)` | The full M ladder including M5/M6/M7. |

### Failure codes

`unknown_flag` (B1) · `market_unresolvable` (M4c) · `submarket_required` (M5) ·
`code_taken` (G3) · `blocked_string` (G7) · `malformed` (G4) ·
`market_conflict` (M7) · `race_lost` (G8)

`submarket_required` is the interesting one: it means the market collided and
the standard wants a real place to split on rather than a counter. Surface it
as a prompt ("Which part of town?"), not an error.

## OpsCore integration

### Where the data lives

```
properties/{propertyId}        the record. Internal key, never the code (G1).
innCodes/{CODE}                uniqueness ledger. Written once, never deleted (G3).
marketCodes/{MARKET}           market and submarket claims (M6, M7).
submarketIndex/{city|ST|sub}   reverse lookup for M6.
```

Firestore cannot enforce uniqueness on a *field*, so the code is a **document
ID**. Creating a document that already exists inside a transaction fails, and
that failure is the real guarantee. This is why issuance must not be a
client-side write.

### Cloud Function

```ts
import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { getFirestore } from 'firebase-admin/firestore';
import { MHG_CONFIG, issueCode } from '@mcx/inn-code';
import { FirestoreRegistry } from '@mcx/inn-code/firestore';

export const issueInnCode = onCall(async (request) => {
  if (!request.auth?.token?.['mhgAdmin']) {
    throw new HttpsError('permission-denied', 'Standards owner only.');
  }
  const registry = new FirestoreRegistry(getFirestore());
  const result = await issueCode({ config: MHG_CONFIG, registry }, request.data);
  if (!result.ok) {
    throw new HttpsError('failed-precondition', result.failure.message, {
      rule: result.failure.rule,
      code: result.failure.code,
      trace: result.trace,
    });
  }
  return { record: result.record, trace: result.trace };
});
```

`deriveCode` can run client-side for the live preview — it only reads. Keep
`issueCode` behind the function.

### Security rules

```
match /innCodes/{code}    { allow read: if request.auth != null; allow write: if false; }
match /marketCodes/{m}    { allow read: if request.auth != null; allow write: if false; }
match /submarketIndex/{k} { allow read: if request.auth != null; allow write: if false; }
match /properties/{id}    { allow read: if request.auth != null; allow write: if false; }
```

`write: if false` blocks clients but not the Admin SDK, which bypasses rules.
A client that can write `innCodes` can break G3.

## Extending

**A new flag.** Add a row to `src/config/brands.ts`. Never reuse a code, never
delete a row — mark a dead brand `retired: true` so historical codes keep
resolving (B4). `guards.test.ts` fails the build on a duplicate.

**Wider airport coverage.** `AIRPORT_CODES` is curated, not exhaustive; M3/M4
handle anything missing, and a wrong airport code is worse than none. To widen
it, filter the OurAirports dataset to `type in (large_airport, medium_airport)`
with a non-empty `iata_code` and merge at build time.

**A second operator.** Everything the engine reads is data on a `CodeConfig`.
Nothing in `src/rules/` mentions MHG. A second management company is a second
config object — different brand table, different market length, different
blocked strings — passed to the same functions. That was the point of the
"built to generalize" call; making it multi-tenant is wiring a config loader,
not a rewrite.

## Design notes

**Why the code is not the primary key (G1).** A rebrand changes the flag, which
changes the code. If the code were the key, every foreign key in OpsCore would
have to be rewritten on a conversion. `propertyId` is immutable; the code is an
attribute of it, and `rebrand` proves it by keeping the id across the change.

**Why collisions move into the market segment.** A trailing counter (`EVVHX2`)
would have been easier and means nothing. The M5 split puts the tiebreaker
somewhere a person can read it: `EVWHX` is the Hampton on the west side.

**Why a base market code is not bound to one city.** Newburgh sits under `EVV`
by design (M2, M8). A market claim from M1/M2 is bound to the *market*; only a
code derived from a city name, split under M5, or assigned by hand is bound to
a specific place. `src/rules/claim.ts` is where that distinction lives, and
getting it wrong is what makes a code system start refusing legitimate
properties.

**Why the incumbent keeps its code when a market splits.** The first Hampton in
Evansville East holds `EVVHX`. When a second Hampton arrives, East gets its own
code and the incumbent keeps `EVVHX` — codes are immutable (M7). So a submarket
can contain one property on the base code and later ones on the split code.
That asymmetry is deliberate; the alternative is reissuing codes, which G3
forbids.

## Test coverage

```
test/market.test.ts   M1–M8: metro codes, airport lookup, name derivation,
                      the IATA screen, submarket splits, claim permanence
test/engine.test.ts   all nine worked examples against one registry, derive/issue
                      separation, races, concurrency, rebrand, retirement
test/guards.test.ts   G4, G7, B1, and config integrity (duplicate flags,
                      malformed market codes, I/O excluded from the ladder)
```

The concurrency test is the one that matters: three simultaneous issuances in
the same market produce three distinct codes and three records, never two
writers holding one code.
